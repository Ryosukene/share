# -*- coding: utf-8 -*- #
"""*********************************************************************************************"""
#   FileName     [ upstream/audio_albert/expert.py ]
#   Synopsis     [ the audio albert wrapper ]
#   Author       [ S3PRL ]
#   Copyright    [ Copyleft(c), Speech Lab, NTU, Taiwan ]
"""*********************************************************************************************"""


###############
# IMPORTATION #
###############
from ..mockingjay.expert import UpstreamExpert